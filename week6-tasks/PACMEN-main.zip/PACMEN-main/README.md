# PacMen Project

In this project is to create a pacman on demand (button click) and move these pacmen across the page.

## Steps to Run the Project

Step 1: Click "Add pacMan" button to create pacmen at random position on the screen.

Step 2: Click "Start Game" button to move pacmen at axis with random velocity.

## Future improvements

The project can be further enhance by adding different pacmen with more creatives,animations and sound effects.
